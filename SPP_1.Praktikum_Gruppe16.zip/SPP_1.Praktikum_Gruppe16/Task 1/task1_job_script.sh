#!/bin/bash
#SBATCH -A kurs00051
#SBATCH -p kurs00051
#SBATCH --reservation=kurs00051
#SBATCH -J daxpy
#SBATCH -e /home/kurse/kurs00051/mt45qyry/task1.err.%j
#SBATCH -o /home/kurse/kurs00051/mt45qyry/task1.out.%j
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --mem-per-cpu=3800
#SBATCH -t 00:10:00

module purge
module load gcc

cd home/kurse/kurs00051/mt45qyry/
./daxpy 1
./daxpy 2
./daxpy 4
./daxpy 8
./daxpy 16