#!/bin/bash
#SBATCH -A kurs00051
#SBATCH -p kurs00051
#SBATCH --reservation=kurs00051
#SBATCH -J matmul_symmetric
#SBATCH --mail-type=ALL
#SBATCH -e /home/kurse/kurs00051/mt45qyry/task2.err.%j
#SBATCH -o /home/kurse/kurs00051/mt45qyry/task2.out.%j
#SBATCH -n 1
#SBATCH -c 32
#SBATCH --mem-per-cpu=3800
#SBATCH -t 00:10:00

module purge
module load gcc

cd home/kurse/kurs00051/mt45qyry/
./matmul_symmetric 1
./matmul_symmetric 2
./matmul_symmetric 4
./matmul_symmetric 8
./matmul_symmetric 16
./matmul_symmetric 32
