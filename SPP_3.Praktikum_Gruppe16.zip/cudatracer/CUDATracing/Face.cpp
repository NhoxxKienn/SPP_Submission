#include "Face.h"

Face::Face(int p0, int p1, int p2)
{
	this->p0 = p0;
	this->p1 = p1;
	this->p2 = p2;
}