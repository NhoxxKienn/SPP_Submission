//  Author:
//
//    Yannic Fischler
//    Modfied for WS21 by Sebastian Kreutzer

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <mpi.h>
#include <math.h>


int world_size;
int world_rank;


int main(int argc, char** argv) {
  int i;
  double x, myResult;
  MPI_Init(&argc, &argv);

  // TODO: Store number of processes in world_size
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);
  // TODO: Store current rank in world_rank
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

  if (argc != 2) {
    printf("Add number of sampling points as parameter\n");
    return 1;
  }

  int numberOfPoints = atoi(argv[1]);

  // TODO: Make sure that numberOfPoints is valid
  if (numberOfPoints < world_size) {
      numberOfPoints = world_size;
  }

  if (world_rank == 0) {
    printf("Running with %d processes\n", world_size);
  }

  double result = 0;
  myResult = 0.0;
  srand(time(NULL) + world_rank);
  // TODO: Implement the Monte-Carlo simulation as described in the task.
  //       Store the solution in "result".
  for (i = world_rank; i < numberOfPoints; i += world_size) {
          x = -1 + ((double)(rand()) / (double)RAND_MAX) * 2;
          myResult += ((double)2 / (double)numberOfPoints) *
              ((double)2 / (double)(1 + x * x));
  }
  
  int pow = 1;
  int iterations = ceil(log(world_size) / log(2));
  int done = 0;
  for (i = 1; i <= iterations; i++) {
      pow *= 2;
      if (world_rank % pow == 0) {
          int sender = world_rank + (pow / 2);
          if (sender < world_size) {
              MPI_Recv(&result, 1, MPI_DOUBLE, sender, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
              myResult += result;
              result = myResult;
          }
      }
      else {
          if (!done) {
              int receiver = world_rank - (pow / 2);
              MPI_Send(&myResult, 1, MPI_DOUBLE, receiver, 1, MPI_COMM_WORLD);
              done = 1;
          }
      }
  }

  if (world_rank == 0) {
    printf("%f\n", result);
  }

  MPI_Finalize();

  return 0;

}



